export const $NAME$ = (action$: ActionsObservable<Action<RootState>>): Observable<Action> =>
  action$.pipe(
    filter(),
    mergeMap(() => {}),
  );
